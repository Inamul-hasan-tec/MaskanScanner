import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { DataTable } from 'react-native-paper';
import { baseURL } from '../screens/const/const';
const Tables = () => {
  const [userData, setUserData] = useState([]);
  const [currentDate, setCurrentDate] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${baseURL}/user-data/younus@gmail.com`);
	  console.log("API response @@@@@@c    : " , response.data.rows2[0].name , response.data );
      setUserData(response.data.rows2);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  

  useEffect(() => {
    var date = new Date().getDate(); //Current Date
    var month = new Date().getMonth() + 1; //Current Month
    var year = new Date().getFullYear(); //Current Year
    var hours = new Date().getHours(); //Current Hours
    var min = new Date().getMinutes(); //Current Minutes
    var sec = new Date().getSeconds(); //Current Seconds
    setCurrentDate(
      date + '/' + month + '/' + year 
      + ' ' + hours + ':' + min
    );
  }, []);


  return (
    <ScrollView horizontal={true}>

      <DataTable style={styles.container}>
      <DataTable.Header style={styles.tableHeader}>
        <DataTable.Title>S.No</DataTable.Title>
        <DataTable.Title>Gender</DataTable.Title>
        <DataTable.Title>Date/Time</DataTable.Title>
        
        <DataTable.Title>Area</DataTable.Title>
       
       
      </DataTable.Header>
      
	 
      {userData.map((user, index) => (
        <DataTable.Row key={user.id}>
          <DataTable.Cell>{index + 1}</DataTable.Cell>
          
          <DataTable.Cell>{user.gender}</DataTable.Cell>
          <DataTable.Cell>{currentDate}</DataTable.Cell>
         
          <DataTable.Cell>{user.geo_loc}</DataTable.Cell>
          
         
        
          {/* <DataTable.Cell style={styles.verified}>Verified</DataTable.Cell> */}
        </DataTable.Row>
      ))}
     
    </DataTable>
    <View>
        <Text style={{fontSize:20,fontWeight:400}}>Total Count = </Text>
        
</View>
    </ScrollView>
  );
};

export default Tables;

const styles = StyleSheet.create({
  container: {
    padding: 15,
  },
  tableHeader: {
    backgroundColor: '#FAB707',
    width: '100%',
  },
  verified: {
    // Add styles for verified cells
    color: 'green',
  },
});
