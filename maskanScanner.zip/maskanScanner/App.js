// import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from "react-native";
import Splash from "./screens/Splash";
import Login from "./screens/Login";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import CreateAccount from "./screens/CreateAccount";
import ScanPage from "./screens/ScanPage";
import Focus from "./screens/Focus";
import Report from "./screens/Report";
import VerifiedScreen from "./screens/VerifiedScreen";
import DepotScreen from "./screens/DepotScreen"
import ReadPdf from "./screens/ReadPdf";
import CustomScreen from "./screens/CustomScreen";
const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen component={Splash} name="splash" />
        <Stack.Screen component={Login} name="Login" />
        <Stack.Screen component={CustomScreen} name="CustomScreen" />
        <Stack.Screen component={CreateAccount} name="CreateAccount" />
        <Stack.Screen component={ScanPage} name="ScanPage" />
        <Stack.Screen component={VerifiedScreen} name="VerifiedScreen" />
        <Stack.Screen component={ReadPdf} name="ReadPdf" />
        {/* <Stack.Screen component={Focus} name="Focus" /> */}
        <Stack.Screen component={Report} name="Report" />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#2196f3",
    alignItems: "center",
    justifyContent: "center",
  },
});
