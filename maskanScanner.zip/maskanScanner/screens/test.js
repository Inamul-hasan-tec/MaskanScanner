// import { StatusBar } from "expo-status-bar";

// import React, { useState, useEffect } from "react";
// import { BarCodeScanner } from "expo-barcode-scanner";
// import axios from "axios";
// import { baseURL } from "./const/const";
// import * as convert from "xml-js";
// import { useNavigation } from "@react-navigation/native";
// import * as Location from 'expo-location';

// import {
//   StyleSheet,
//   Text,
//   View,
//   Image,
//   TextInput,
//   Button,
//   TouchableOpacity,
// } from "react-native";
// import Focus from "./Focus";
// // import Focus from "./Focus";
// export default function ScanPage({ navigation }) {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [aadhaaruid, setAadhaaruid] = useState({});
//   const [hasPermission, setHasPermission] = React.useState(true);
//   const [scanData, setScanData] = React.useState(false);
//   const [location, setLocation] = useState();
//   const [address, setAddress] = useState();
//   const [dist,setdist] = useState();
//   const [dob,setdob] = useState();
//   const [gender,setgender] = useState();
//   const [house,sethouse] = useState();
//   const [name,setname] = useState();
//   const [loc,setloc] = useState();
//   const [pc,setpc] = useState();
//   const [po,setpo] = useState();
//   const [state,setstate] = useState();
//   const [street,setstreet] = useState();
//   const [subdist,setsubdist] = useState();
//   const [uid,setuid] = useState();
//   const [vtc,setvtc] = useState();
//   const [yob,setyob] = useState();
//   const [geo_loc, setGeoLoc] = useState('');
//   let loc1;
  
 


   
  
//   // };
//   useEffect(() => {
//     const getPermissions = async () => {
//       let { status } = await Location.requestForegroundPermissionsAsync();
//       if (status !== 'granted') {
//         console.log("Please grant location permissions");
//         return;
//       }

//       let currentLocation = await Location.getCurrentPositionAsync({});
//       setLocation(currentLocation);
//       console.log("Location:");
//       console.log(currentLocation);
      
//     };
//     getPermissions();
//   }, []);
//   const reverseGeocode = async () => {
//     const reverseGeocodedAddress = await Location.reverseGeocodeAsync({
//       longitude: location.coords.longitude,
//       latitude: location.coords.latitude
//     });

//     console.log("Reverse Geocoded:");
//     console.log(reverseGeocodedAddress[0]?.district);
//     loc1=reverseGeocodedAddress[0]?.district;
//     // console.log(reverseGeocodedAddress);
   
//   };
  

  

  

//   const handleBarCodeScanned = ({ type, data }) => {
//     setScanData(true);
//     let result = JSON.parse(convert.xml2json(data));
//     // console.log("Final 123 : ",result);
//     // console.log("XML to JSON : ", typeof( result));
//     // console.log("parsed data : ", result?.elements[0]?.attributes?.uid);
//     let finalData = result?.elements[0]?.attributes;
//     // setco(finalData?.co);
//     setdist(finalData?.dist);
//     setdob(finalData?.dob);
//     setgender(finalData?.gender);
//     sethouse(finalData?.house);
//     setname(finalData?.name);
//     setloc(finalData?.loc);
//     setpc(finalData?.pc);
//     setpo(finalData?.po);
//     setstate(finalData?.state);
//     setstreet(finalData?.street);
//     setsubdist(finalData?.subdist);
//     setuid(finalData?.uid);
//     setvtc(finalData?.vtc);
//     setyob(finalData?.yob);
    

    

//     setAadhaaruid({
//       uid: finalData.uid,
//       name: finalData.name,
//       mobile: "XXXXXXXXXX",
//       gender: finalData.gender,
//       yob: finalData.yob,
//       co: finalData.co,
//       house: finalData.house,
//       street: finalData.street,
//       loc: finalData.loc,
//       vtc: finalData.vtc,
//       po: finalData.po,
//       dist: finalData.dist,
//       subdist: finalData.subdist,
//       state: finalData.state,
//       pc: finalData.pc,
//       dob: finalData.dob,
//       geo_loc:loc1,
      
     
//     });
//   reverseGeocode();
    

   

    

    
//     //  navigation.navigate("VerifiedScreen", {responseData : response.data});
//   };

//   return (
//     <View style={styles.container}>
//       <Image style={styles.image} source={require("../assets/adhar.png")} />
//       <StatusBar style="auto" />
//       <View
//         style={{
//           width: "80%",
//           height: 350,
//           borderWidth: 1,
//           borderColor: "#FAB707",
//         }}
//       >
//         <View style={styles.containerF}>
//           <BarCodeScanner
//             style={StyleSheet.absoluteFillObject}
//             onBarCodeScanned={scanData ? undefined : handleBarCodeScanned}
//           />

//           {/* {scanData && <Button  title='Scan Again?' onPress={() => setScanData(undefined)} />} */}

//           <StatusBar style="auto" />
//         </View>
//       </View>
     

//       <TouchableOpacity
//         onPress={reverseGeocode}
//         style={styles.loginBtn}
//       >
//         <Text style={styles.loginText}>Update location</Text>
//       </TouchableOpacity>
//     </View>
//   );
// }
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#fff",
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   containerF: {
//     flex: 1,
//     backgroundColor: "#fff",
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   image: {
//     marginBottom: 40,
//     width: "50%",
//     height: 130,
//   },
//   inputView: {
//     backgroundColor: "#FAB707",
//     borderRadius: 30,
//     width: "70%",
//     height: 45,
//     marginBottom: 20,
//     alignItems: "center",
//   },
//   TextInput: {
//     height: 50,
//     flex: 1,

//     padding: 10,
//     marginLeft: 20,
//   },
//   forgot_button: {
//     height: 30,
//     marginBottom: 30,
//   },
//   loginBtn: {
//     width: "80%",
//     borderRadius: 25,
//     height: 50,
//     alignItems: "center",
//     justifyContent: "center",
//     marginTop: 40,
//     backgroundColor: "#FAB707",
//   },
//   loginText: {
//     fontSize: 20,
//   },
// });
// /////////////////////////////////////////////////

//before black box

import { StatusBar } from "expo-status-bar";

import React, { useState, useEffect } from "react";
import { BarCodeScanner } from "expo-barcode-scanner";
import axios from "axios";
import { baseURL } from "./const/const";
import * as convert from "xml-js";
import { useNavigation } from "@react-navigation/native";
import * as Location from 'expo-location';

import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
} from "react-native";
import Focus from "./Focus";
// import Focus from "./Focus";
export default function ScanPage({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [aadhaaruid, setAadhaaruid] = useState({});
  const [hasPermission, setHasPermission] = React.useState(true);
  const [scanData, setScanData] = React.useState(false);
  const [location, setLocation] = useState();
  const [address, setAddress] = useState();
  const [dist,setdist] = useState();
  const [dob,setdob] = useState();
  const [gender,setgender] = useState();
  const [house,sethouse] = useState();
  const [name,setname] = useState();
  const [loc,setloc] = useState();
  const [pc,setpc] = useState();
  const [po,setpo] = useState();
  const [state,setstate] = useState();
  const [street,setstreet] = useState();
  const [subdist,setsubdist] = useState();
  const [uid,setuid] = useState();
  const [vtc,setvtc] = useState();
  const [yob,setyob] = useState();
  const [geo_loc, setGeoLoc] = useState('');
  const [x1,setx1] = useState('');
 


   
  
  // };
  useEffect(() => {
    const getPermissions = async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log("Please grant location permissions");
        return;
      }

      let currentLocation = await Location.getCurrentPositionAsync({});
      setLocation(currentLocation);
      console.log("Location:");
      console.log(currentLocation);
      
    };
    getPermissions();
  }, []);
  const reverseGeocode = async () => {
    const reverseGeocodedAddress = await Location.reverseGeocodeAsync({
      longitude: location.coords.longitude,
      latitude: location.coords.latitude
    });

    console.log("Reverse Geocoded:");
    console.log(reverseGeocodedAddress[0]?.district);
    const loc2=reverseGeocodedAddress[0]?.district
    setx1(loc2);
    //console.log("Loc1 --" + loc1);
    
    // console.log(reverseGeocodedAddress);
   
  };
  reverseGeocode();
  

  const postUserData = async (userData) => {
    try {
      // console.log("ENter the post api" , userData);
      
      const response = await axios.post(
        "http://192.168.1.17:1000/verify-user",
        JSON.stringify(userData),
        {
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Post data response:", response.data.results[0].name);
      console.log("Post data response:", response.data.results[0].uid);
      console.log("Post data message:", response.data.message);
      console.log("Post data message:", response.data);
      //msg=response.data.message;
      //GolbalObj= msg;
      //return response.data; // You can return the response if needed
      //const dataToSend = GolbalObj ; 
      navigation.navigate("VerifiedScreen", { data: [response.data.message, response.data.results[0].uid, response.data.results[0].name ,  response.data.results[0].dob ,  response.data.results[0].gender]  });
    } catch (error) {
      // console.error("Error posting data:", error);
      throw error; // You can throw the error or handle it as per your needs
    }
  };

  

  const handleBarCodeScanned = ({ type, data }) => {
    setScanData(true);
    let result = JSON.parse(convert.xml2json(data));
    // console.log("Final 123 : ",result);
    // console.log("XML to JSON : ", typeof( result));
    // console.log("parsed data : ", result?.elements[0]?.attributes?.uid);
    let finalData = result?.elements[0]?.attributes;
    // setco(finalData?.co);
    setdist(finalData?.dist);
    setdob(finalData?.dob);
    setgender(finalData?.gender);
    sethouse(finalData?.house);
    setname(finalData?.name);
    setloc(finalData?.loc);
    setpc(finalData?.pc);
    setpo(finalData?.po);
    setstate(finalData?.state);
    setstreet(finalData?.street);
    setsubdist(finalData?.subdist);
    setuid(finalData?.uid);
    setvtc(finalData?.vtc);
    setyob(finalData?.yob);
    // setGeoLoc(loc1);
    

    

    setAadhaaruid({
      uid: finalData.uid,
      name: finalData.name,
      mobile: "XXXXXXXXXX",
      gender: finalData.gender,
      yob: finalData.yob,
      co: finalData.co,
      house: finalData.house,
      street: finalData.street,
      loc: finalData.loc,
      vtc: finalData.vtc,
      po: finalData.po,
      dist: finalData.dist,
      subdist: finalData.subdist,
      state: finalData.state,
      pc: finalData.pc,
      dob: finalData.dob,
      geo_loc:x1,
      
     
    });

   

    postUserData({
      uid: finalData.uid,
      name: finalData.name,
      mobile: "XXXXXXXXXX",
      gender: finalData.gender,
      yob: finalData.yob,
      co: finalData.co,
      house: finalData.house,
      street: finalData.street,
      loc: finalData.loc,
      vtc: finalData.vtc,
      po: finalData.po,
      dist: finalData.dist,
      subdist: finalData.subdist,
      state: finalData.state,
      pc: finalData.pc,
      dob: finalData.dob,
      email:finalData.email,
      geo_loc:x1,
      

    });

    
    //  navigation.navigate("VerifiedScreen", {responseData : response.data});
  };

  return (
    <View style={styles.container}>
      <Image style={styles.image} source={require("../assets/adhar.png")} />
      <StatusBar style="auto" />
      <View
        style={{
          width: "80%",
          height: 350,
          borderWidth: 1,
          borderColor: "#FAB707",
        }}
      >
        <View style={styles.containerF}>
          <BarCodeScanner
            style={StyleSheet.absoluteFillObject}
            onBarCodeScanned={scanData ? undefined : handleBarCodeScanned}
          />

          {/* {scanData && <Button  title='Scan Again?' onPress={() => setScanData(undefined)} />} */}

          <StatusBar style="auto" />
        </View>
      </View>
     

      <TouchableOpacity
        onPress={reverseGeocode}
        style={styles.loginBtn}
      >
        <Text style={styles.loginText}>Update location</Text>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  containerF: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    marginBottom: 40,
    width: "50%",
    height: 130,
  },
  inputView: {
    backgroundColor: "#FAB707",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,
    alignItems: "center",
  },
  TextInput: {
    height: 50,
    flex: 1,

    padding: 10,
    marginLeft: 20,
  },
  forgot_button: {
    height: 30,
    marginBottom: 30,
  },
  loginBtn: {
    width: "80%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    backgroundColor: "#FAB707",
  },
  loginText: {
    fontSize: 20,
  },
});
/////////////////////////////////////////////////
