import { StatusBar } from "expo-status-bar";
import { SelectList } from "react-native-dropdown-select-list";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
} from "react-native";
import axios from "axios";
import { baseURL } from "../screens/const/const";
import React ,{useState,useEffect}from "react";
export default function Login({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [selected, setSelected] = React.useState("");
  const [selectedRout, setselectedRout] = React.useState("");
  const [logindata, setLogindata] = useState({
    email:"",
        password:"",
       date:"2023-12-27",
        depot:"",
        route:"",
        shift:"start",
        
       

});

//   const fetchData = async () => {
//     console.log("Entered the fetch data");
//     try {
//       const response = await axios.post(
//         `${baseURL}/login-user`,
//         JSON.stringify(logindata),
//         { headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' } }
//       );

//       console.log("vfuc",response.data); // Assuming the response contains data field
//       // Handle the response as needed
//       // navigate("Addplan", { replace: true });
//     } catch (error) {
//       alert("Error: Fill the details properly");
//       console.error(error);
//       console.log(error.response);
//     }
//   };
// console.log("Data = ", logindata);

  const handleLogin = () => {
    const apiUrl = `${baseURL}/login-user`;

    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');

   var raw = JSON.stringify({
  "email":email ,
  "password": password,
  "date": "2023-12-25",
  "depot": selected,
  "route": selectedRout,
  "shift": "start"
});

    const requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw,
      redirect: 'follow',
    };

    fetch(apiUrl, requestOptions)
      .then(response => response.text())
      .then(result => console.log(result))
      .catch(error => console.log('error', error));
  };
  // ----------
//   var myHeaders = new Headers();
// myHeaders.append("Content-Type", "application/json");

// var raw = JSON.stringify({
//   "email":email ,
//   "password": password,
//   "date": "2023-12-25",
//   "depot": selected,
//   "route": selectedRout,
//   "shift": "start"
// });

// var requestOptions = {
//   method: 'POST',
//   headers: myHeaders,
//   body: raw,
//   redirect: 'follow'
// };

// fetch("http://192.168.1.17:1000/login-user", requestOptions)
//   .then(response => response.text())
//   .then(result => console.log(result))
//   .catch(error => console.log('error', error));


  const data = [
    { key: "1", value: "ACHAMPET", disabled: false },
    { key: "2", value: "ADILABAD", disabled: false },
    { key: "3", value: "ARMOOR", disabled: false },
    { key: "4", value: "ASIFABAD", disabled: false },
    { key: "5", value: "BANDLAGUDA", disabled: false },
    { key: "6", value: "BANSWADA", disabled: false },
    { key: "7", value: "BHAINSA", disabled: false },
    { key: "8", value: "BARKATPURA", disabled: false },
    { key: "9", value: "BHEL", disabled: false },
    { key: "10", value: "BHADRACHALAM", disabled: false },
    { key: "11", value: "BHUPALAPALLE", disabled: false },
    { key: "12", value: "BODHAN", disabled: false },
    { key: "13", value: "CHENGICHERLA", disabled: false },
    { key: "14", value: "CONTONMENT", disabled: false },
    { key: "15", value: "DEVARAKONDA", disabled: false },
    { key: "16", value: "DILSUKHNAGAR", disabled: true },
    { key: "17", value: "DUBBAKA", disabled: false },
    { key: "18", value: "FALAKNUMA", disabled: false },
    { key: "19", value: "FAROOQNAGAR", disabled: false },
    { key: "20", value: "GADWAL", disabled: false },
    { key: "21", value: "GAJWEL-PRAGNAPUR", disabled: false },
    { key: "22", value: "GODAVARIKHANI", disabled: false },
    { key: "23", value: "HAKEEMPET", disabled: false },
    { key: "24", value: "HANAMKONDA", disabled: false },
    { key: "25", value: "HAYATNAGAR -1", disabled: false },
    { key: "26", value: "HAYATNAGAR -2", disabled: false },
    { key: "27", value: "HUSNABAD", disabled: false },
    { key: "28", value: "HUZURABAD", disabled: false },
    { key: "29", value: "HYDERABAD CENTRAL UNIVERSITY", disabled: false },
    { key: "30", value: "HYDERABAD -1", disabled: false },
    { key: "31", value: "HYDERABAD -2", disabled: false },
    { key: "32", value: "IBRAHIMPATNAM-HYD", disabled: false },
    { key: "33", value: "JAGITYAL", disabled: false },
    { key: "34", value: "JANGAON", disabled: false },
    { key: "35", value: "JEEDIMETLA", disabled: false },
    { key: "36", value: "KACHIGUDA", disabled: false },
    { key: "37", value: "KALWAKURTHY", disabled: false },
    { key: "38", value: "KAMAREDDY", disabled: false },
    { key: "39", value: "KARIMNAGAR -1", disabled: false },
    { key: "40", value: "KARIMNAGAR -2", disabled: false },
    { key: "41", value: "KHAMMAM", disabled: false },
    { key: "42", value: "KODAD", disabled: false },
    { key: "43", value: "KOLLAPUR", disabled: false },
    { key: "44", value: "KORUTLA", disabled: false },
    { key: "45", value: "KOTHAGUDEM", disabled: false },
    { key: "46", value: "KOSGI", disabled: false },
    { key: "47", value: "KUKATPALLY", disabled: false },
    { key: "48", value: "KUSHAIGUDA", disabled: false },
    { key: "49", value: "MADHIRA", disabled: false },
    { key: "50", value: "MAHABOOBABAD", disabled: false },
    { key: "51", value: "MAHABOOBNAGAR", disabled: false },
    { key: "52", value: "MAHESWARAM", disabled: false },
    { key: "53", value: "MANCHERIAL", disabled: false },
    { key: "54", value: "MANTHANI", disabled: false },
    { key: "55", value: "MANUGUR", disabled: false },
    { key: "56", value: "MEDAK", disabled: false },
    { key: "57", value: "MEDCHAL", disabled: false },
    { key: "58", value: "MEHADIPATNAM", disabled: false },
    { key: "59", value: "METPALLY", disabled: false },
    { key: "60", value: "MIDHANI", disabled: false },
    { key: "61", value: "MIRYALGUDA", disabled: false },
    { key: "62", value: "MIYAPUR -1", disabled: false },
    { key: "63", value: "MIYAPUR -2", disabled: false },
    { key: "64", value: "MUSHIRABAD -1", disabled: false },
    { key: "65", value: "MUSHIRABAD -2", disabled: false },
    { key: "66", value: "NAGARKURNOOL", disabled: false },
    { key: "67", value: "NALGONDA", disabled: false },
    { key: "68", value: "NARAYANAKHED", disabled: false },
    { key: "69", value: "NARAYANPET", disabled: false },
    { key: "70", value: "NARKETPALLY", disabled: false },
    { key: "71", value: "NARSAMPET", disabled: false },
    { key: "72", value: "NARSAPUR", disabled: false },
    { key: "73", value: "NIRMAL", disabled: false },
    { key: "74", value: "NIZAMABAD -1", disabled: false },
    { key: "75", value: "NIZAMABAD -2", disabled: false },
    { key: "76", value: "PARGI", disabled: false },
    { key: "77", value: "PARKAL", disabled: false },
    { key: "78", value: "PICKET", disabled: false },
    { key: "79", value: "RAJENDRANAGAR", disabled: false },
    { key: "80", value: "RANIGUNJ -1", disabled: false },
    { key: "81", value: "RANIGUNJ -2", disabled: false },
    { key: "82", value: "SANGA REDDY", disabled: false },
    { key: "83", value: "SATTUPALLY", disabled: false },
    { key: "84", value: "SHADNAGAR", disabled: false },
    { key: "85", value: "SIDDIPET", disabled: false },
    { key: "86", value: "SIRCILLA", disabled: false },
    { key: "87", value: "SURYAPET", disabled: false },
    { key: "88", value: "TANDUR", disabled: false },
    { key: "89", value: "TORRUR", disabled: false },
    { key: "90", value: "UPPAL", disabled: false },
    { key: "91", value: "UTNOOR", disabled: false },
    { key: "92", value: "VEMULAWADA", disabled: false },
    { key: "93", value: "VIKARABAD", disabled: false },
    { key: "94", value: "WANAPARTHY", disabled: false },
    { key: "95", value: "WARANGAL -1", disabled: false },
    { key: "96", value: "WARANGAL -2", disabled: false },
    { key: "97", value: "YADAGIRIGUTTA", disabled: false },
    { key: "98", value: "ZAHIRABAD", disabled: true },
  ];
  const busRoutesData = [
    { key: "1", value: "TSRTC Sathupally Rajahmundry", disabled: false },
    { key: "2", value: "TSRTC Siddipet Mumbai", disabled: false },
    { key: "3", value: "TSRTC Wyra Hyderabad", disabled: false },
    {
      key: "4",
      value: "TSRTC Nirmal Pamuru (Prakasham District)",
      disabled: false,
    },
    { key: "5", value: "TSRTC Tirupati Khammam", disabled: false },
    { key: "6", value: "TSRTC Hyderabad Bayyaram", disabled: false },
    {
      key: "7",
      value: "TSRTC Aswapuram Guntur (Andhra Pradesh)",
      disabled: false,
    },
    {
      key: "8",
      value: "TSRTC Karimnagar Palavancha (Palwancha)",
      disabled: false,
    },
    { key: "9", value: "TSRTC Eturnagaram Rajahmundry", disabled: false },
    { key: "10", value: "TSRTC Singarayakonda Sadashivpet", disabled: false },
    { key: "11", value: "TSRTC Kodad Armoor", disabled: false },
    { key: "12", value: "TSRTC Suryapet Bangalore", disabled: false },
    { key: "13", value: "TSRTC Chirala Hyderabad", disabled: false },
    {
      key: "14",
      value: "TSRTC Mallepalli (Telangana) Singarayakonda",
      disabled: false,
    },
    { key: "15", value: "TSRTC Jadcherla Mydukur", disabled: false },
    { key: "16", value: "TSRTC Sangareddy Hyderabad", disabled: false },
    {
      key: "17",
      value: "TSRTC Mall (Telangana) Singarayakonda",
      disabled: false,
    },
    {
      key: "18",
      value: "TSRTC Karimnagar Udayagiri (Andhra Pradesh)",
      disabled: false,
    },
    { key: "19", value: "TSRTC Eturnagaram Jangareddigudem", disabled: false },
    { key: "20", value: "TSRTC Kothagudem Tirupati", disabled: false },
    {
      key: "21",
      value: "TSRTC Guntur (Andhra Pradesh) Khammam",
      disabled: false,
    },
    { key: "22", value: "TSRTC Govindaraopet Eturnagaram", disabled: false },
    { key: "23", value: "TSRTC Annavaram Khammam", disabled: false },
    { key: "24", value: "TSRTC Medak U (Telangana) Nandyal", disabled: false },
    { key: "25", value: "TSRTC Miryalaguda Tirupati", disabled: false },
    { key: "26", value: "TSRTC Piduguralla Kavali", disabled: false },
    { key: "27", value: "TSRTC Adilabad Nandigama", disabled: false },
    { key: "28", value: "TSRTC Ahmednagar Hyderabad", disabled: false },
    { key: "29", value: "TSRTC Tadepalligudem Hyderabad", disabled: false },
    {
      key: "30",
      value: "TSRTC Kamalapuram (Telangana) Aswapuram",
      disabled: false,
    },
    { key: "31", value: "TSRTC Kadapa Godavarikhani", disabled: false },
    {
      key: "32",
      value: "TSRTC Vijayawada Pasara (Telangana)",
      disabled: false,
    },
    { key: "33", value: "TSRTC Punganur Hyderabad", disabled: false },
    {
      key: "34",
      value: "TSRTC Vinjamur (Andhra Pradesh) Darsi",
      disabled: false,
    },
    { key: "35", value: "TSRTC Gooty Hyderabad", disabled: false },
    { key: "36", value: "TSRTC Rajahmundry Burgampad", disabled: false },
    { key: "37", value: "TSRTC Nellore Kothagudem", disabled: false },
    { key: "38", value: "TSRTC Bodhan (Telangana) Nellore", disabled: false },
    { key: "39", value: "TSRTC Kavali Nellore", disabled: false },
    { key: "40", value: "TSRTC Burgampad Ravulapalem", disabled: false },
    {
      key: "41",
      value: "TSRTC Mall (Telangana) Macherla (Andhra Pradesh)",
      disabled: false,
    },
    { key: "42", value: "TSRTC Solapur Sangareddy", disabled: false },
    { key: "43", value: "TSRTC Hyderabad Koyyalagudem", disabled: false },
    { key: "44", value: "TSRTC Burgampad Rajahmundry", disabled: false },
    { key: "45", value: "TSRTC Nirmal Warangal", disabled: false },
    {
      key: "46",
      value: "TSRTC Kavali Guntur (Andhra Pradesh)",
      disabled: false,
    },
    { key: "47", value: "TSRTC Siddipet Markapuram", disabled: false },
    { key: "48", value: "TSRTC Kodad Ravulapalem", disabled: false },
    { key: "49", value: "TSRTC Kothakota Allagadda", disabled: false },
    {
      key: "50",
      value: "TSRTC Bhadrachalam Kamalapuram (Telangana)",
      disabled: false,
    },
    { key: "51", value: "TSRTC Alladurg (Telangana) Addanki", disabled: false },
    { key: "52", value: "TSRTC Hyderabad Nalajerlla", disabled: false },
    { key: "53", value: "TSRTC Mangapet Warangal", disabled: false },
    { key: "54", value: "TSRTC Hyderabad Kanigiri", disabled: false },
    { key: "55", value: "TSRTC Hyderabad Armoor", disabled: false },
    { key: "56", value: "TSRTC Allagadda Kurnool", disabled: false },
    {
      key: "57",
      value: "TSRTC SriKalahasthi Macherla (Andhra Pradesh)",
      disabled: false,
    },
    {
      key: "58",
      value: "TSRTC Khanapur (Telangana) Hyderabad",
      disabled: false,
    },
    {
      key: "59",
      value: "TSRTC Kavali Palavancha (Palwancha)",
      disabled: false,
    },
    { key: "60", value: "TSRTC Hyderabad Sattenapalle", disabled: false },
    { key: "61", value: "TSRTC Armoor Hyderabad Airport", disabled: false },
    { key: "62", value: "TSRTC Tanguturu Hyderabad", disabled: false },
    { key: "63", value: "TSRTC Ongole Kothagudem", disabled: false },
    { key: "64", value: "TSRTC Vijayawada Bhupalpally", disabled: false },
    { key: "65", value: "TSRTC Kothakota Kadapa", disabled: false },
    { key: "66", value: "TSRTC Pebbair Nandyal", disabled: false },
    { key: "67", value: "TSRTC Pandharpur Zaheerabad", disabled: false },
    { key: "68", value: "TSRTC Allagadda Jadcherla", disabled: false },
    { key: "69", value: "TSRTC Karimnagar Warangal", disabled: false },
    { key: "70", value: "TSRTC Gajwel (Telangana) Panvel", disabled: false },
  ];

  return (
    <View style={styles.container}>
      <Image style={styles.image} source={require("../assets/AadharBus.jpeg")} />
      <StatusBar style="auto" />
      <View style={styles.inputView}>
      <TextInput
          style={styles.TextInput}
          placeholder="Email"
        value={email}
        onChangeText={text => setEmail(text)}
        keyboardType="email-address"
        autoCapitalize="none"
        />
      </View>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Password"
        value={password}
        onChangeText={text => setPassword(text)}
        secureTextEntry={true}
        />
        
      </View>
      <View style={{ marginHorizontal: 10, alignItems: "center" }}>
        <Text style={{ margin: 10 }}>Depot :</Text>
        <SelectList
          setSelected={(val) => setSelected(val)}
          data={data}
          save="value"
        />
      </View>
      <View style={{ marginHorizontal: 10, alignItems: "center" }}>
        <Text style={{ margin: 10 }}>Route :</Text>
        <SelectList
          setSelected={(val) => setselectedRout(val)}
          data={busRoutesData}
          save="valueRout"
        />
      </View>

      <TouchableOpacity
        onPress={() => navigation.navigate("CustomScreen")}
        onPressIn={handleLogin}
        style={styles.loginBtn}
      >
        <Text style={styles.loginText}>LOGIN</Text>
      </TouchableOpacity>
      <View style={{ flexDirection: "row", marginTop: 10 }}>
        <TouchableOpacity onPress={() => navigation.navigate("CreateAccount")}>
          <Text style={styles.forgot_button}>Create Account. </Text>
        </TouchableOpacity>
        <TouchableOpacity>
          <Text style={styles.forgot_button}>Forgot Password?</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    marginBottom: 40,
    width: "50%",
    height: 120,
  },
  inputView: {
    backgroundColor: "#FAB707",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,
    alignItems: "center",
  },
  TextInput: {
    height: 50,
    flex: 1,

    padding: 10,
    marginLeft: 20,
  },
  forgot_button: {
    fontSize: 12,
    marginBottom: 10,
  },
  loginBtn: {
    width: "40%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 30,
    backgroundColor: "#FAB707",
  },
});
