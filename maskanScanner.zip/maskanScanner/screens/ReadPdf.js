// import React, { useEffect, useState } from 'react';
// import { View, StyleSheet, Button, Platform, Text } from 'react-native';
// import * as Print from 'expo-print';
// import axios from 'axios';
// import { shareAsync } from 'expo-sharing';





  





  

// const html = `
// <html>
// <head>
// <style>
// table {
//   font-family: arial, sans-serif;
//   border-collapse: collapse;
//   width: 100%;
// }

// td, th {
//   border: 1px solid #dddddd;
//   text-align: left;
//   padding: 8px;
// }

// tr:nth-child(even) {
//   background-color: #dddddd;
// }
// </style>
// </head>
// <body>

// <h2>Report Data</h2>

// <table>
//   <tr>
//     <th>Sl.No</th>
//     <th>Gender</th>
//     <th>Date/Time</th>
//     <th>Date/Area</th>
//     <th>Date/DOB</th>
//   </tr>
//   <tr>
//     <td>{index+1}</td>
//     <td>{user.gender}</td>
//     <td>{user.gender}</td>
//     <td>{user.gender}</td>
//     <td>{user.gender}</td>
//   </tr>
  
// </table>


// </body>
// </html>
// `;

// export default function ReadPdf() {

//   const [selectedPrinter, setSelectedPrinter] = React.useState();

//   const print = async () => {
    
//     await Print.printAsync({
//       html,

//       printerUrl: selectedPrinter?.url, 
//     });
//   };

//   const printToFile = async () => {
    
//     const { uri } = await Print.printToFileAsync({ html });

//     console.log('File has been saved to:', uri);
    
//     await shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
//   };

//   const selectPrinter = async () => {

//     const printer = await Print.selectPrinterAsync(); 
//     setSelectedPrinter(printer);
//   };
  

//   return (
//     <View style={styles.container}>
//       <Button title="Print Details" onPress={print} />
//       <View style={styles.spacer} />

//       <Button title="Print Details to PDF file" onPress={printToFile} />
//       {Platform.OS === 'ios' && (
//         <>
//           <View style={styles.spacer} />
          
//           <Button title="Select printer" onPress={selectPrinter} />
//           <View style={styles.spacer} />
//           {selectedPrinter ? (
//             {/* <Text style={styles.printer}>{Selected printer: ${selectedPrinter.name}}</Text> */}
//           ) : undefined}
//         </>
//       )}
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     backgroundColor: '#ecf0f1',
//     flexDirection: 'column',
//     padding: 8,
//   },
//   spacer: {
//     height: 8,
//   },
//   printer: {
//     textAlign: 'center',
//   },
// });

import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Button, Platform, Text,TouchableOpacity } from 'react-native';
import * as Print from 'expo-print';
import axios from 'axios';
import {baseURL} from "../screens/const/const"
import { shareAsync } from 'expo-sharing';

const ReadPdf = () => {
  const [selectedPrinter, setSelectedPrinter] = React.useState();
  const [userData, setUserData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${baseURL}/user-data/younus@gmail.com`);
      console.log("API response: ", response.data.rows2);
      setUserData(response.data.rows2);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const generateHtmlTable = () => {
    return `
      <html>
        <head>
          <style>
            table {
              font-family: arial, sans-serif;
              border-collapse: collapse;
              width: 100%;
            }
            
            td, th {
              border: 1px solid #dddddd;
              text-align: left;
              padding: 8px;
            }
            
            tr:nth-child(even) {
              background-color: #dddddd;
            }
          </style>
        </head>
        <body>
          <h2>Report Data</h2>
          <table>
            <tr>
              <th>Sl.No</th>
              <th>Gender</th>
              <th>Date/Time</th>
              <th>Date/Area</th>
              <th>Date/DOB</th>
            </tr>
            ${userData.map((user, index) => (
              `<tr key=${index + 1}>
                <td>${index + 1}</td>
                <td>${user.gender}</td>
                <td>${user.date_time}</td>
                <td>${user.subdist}</td>
                <td>${user.dob}</td>
              </tr>`
            )).join('')}
          </table>
        </body>
      </html>
    `;
  };

  const print = async () => {
    await Print.printAsync({
      html: generateHtmlTable(),
      printerUrl: selectedPrinter?.url,
    });
  };

  const printToFile = async () => {
    const { uri } = await Print.printToFileAsync({ html: generateHtmlTable() });
    console.log('File has been saved to:', uri);
    await shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
  };

  const selectPrinter = async () => {
    const printer = await Print.selectPrinterAsync();
    setSelectedPrinter(printer);
  };

  return (
    <View style={styles.container}>
      <Button title="Print Report" onPress={print} />
      <View style={styles.spacer} />
      <Button title="Share Report" onPress={printToFile} />
      {/* <TouchableOpacity
          onPress={printToFile} 
          style={styles.loginBtn}
          title="Print Details to PDF file"
        >
          <Text style={styles.loginText}>Scan Again</Text>
        </TouchableOpacity> */}
      {Platform.OS === 'ios' && (
        <>
          <View style={styles.spacer} />
          <Button  title="Select printer" onPress={selectPrinter} />
          <View style={styles.spacer} />
          {selectedPrinter ? (
            {/* <Text style={styles.printer}>{Selected printer: ${selectedPrinter.name}}</Text> */}
          ) : undefined}
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    flexDirection: 'column',
    padding: 8,
  },
  spacer: {
    height: 8,
    
  },
  printer: {
    textAlign: 'center',
  },
  Button:{
    
      width: "30%",
      borderRadius: 25,
      height: 50,
      alignItems: "center",
      justifyContent: "center",
      alignSelf: 'center',
      marginTop: 20,
      margin:10,
      backgroundColor: "#fff",
    },
  
});

export default ReadPdf;