import { StatusBar } from "expo-status-bar";
import React, { useState,useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from "react-native";
// import Tables from "./components/Tables";
import Tables from "../asst/Tables";
import axios from "axios";
import { baseURL } from "./const/const";
export default function Report({navigation}) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [count , setCount] = useState("");
 

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${baseURL}/user-count/younuss@mail.com`);
	  console.log("API response @@@@@@c    : " ,response.data.userCount );
    let data2=JSON.stringify(response.data.userCount)

    setCount(data2);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  

  
  return (
    <SafeAreaView>
    <ScrollView >
      <View style={styles.container}>
      
      


<View style={{marginTop:40}}>
<Text style={{fontSize:16,fontWeight:500,margin:10,marginLeft:10}}>
  Total Passengers:   <Text style={{color:'#D80032'}}>
     {count}
  </Text>
</Text>

<Tables />
<View>
  <Button style={{width:'30%',borderRadious:20}} title="Go Back" onPress={()=> navigation.goBack('')} />
</View>
</View>




</View> 
    </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    // justifyContent: "center",
  },
//   image: {c
//     marginBottom: 40,
//     width:"50%",
//     height:120
//   },
//   inputView: {
//     backgroundColor: "#FAB707",
//     borderRadius: 30,
//     width: "70%",
//     height: 45,
//     marginBottom: 20,
//     alignItems: "center",
//   },
//   TextInput: {
//     height: 50,
//     flex: 1,
    
//     padding: 10,
//     marginLeft: 20,
//   },
//   forgot_button: {
//     height: 30,
//     marginBottom: 30,
//   },
//   loginBtn: {
//     width: "80%",
//     borderRadius: 25,
//     height: 50,
//     alignItems: "center",
//     justifyContent: "center",
//     marginTop: 40,
//     backgroundColor: "#FAB707",
//   },
});