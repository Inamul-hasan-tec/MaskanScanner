import { StatusBar } from "expo-status-bar";
import React, { useState, } from "react";
import { useRoute } from "@react-navigation/native";
import { useNavigation } from "@react-navigation/native";


// import LoaderKit from 'react-native-loader-kit'
// import { Loading } from "./components/Loading";

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Alert
} from "react-native";
import { ActivityIndicator } from "react-native-paper";

export default function SuccessPage(props) {
  const navigation = useNavigation();
  console.log(props.route.params.data);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const route = useRoute();
  const receivedData = props.route.params?.data || {};
  const createTwoButtonAlert = () =>
    Alert.alert('Alert', 'End shift', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => console.log('OK Pressed')},
    ]);

  return (
    <ScrollView>
      <View style={styles.container}>
        <View style={{flexDirection:'row',marginTop:10}}>
        <TouchableOpacity
        
          onPress={() => navigation.navigate("Report")}
          style={styles.loginBtn}
        >
          <Text style={styles.loginText}>Reports</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate("CustomScreen")}
          style={styles.loginBtn}
        >
          <Text style={styles.loginText}>Scan Again</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate("ReadPdf")}
          style={styles.loginBtn}
        >
          <Text style={styles.loginText}>Get Report</Text>
        </TouchableOpacity>
        </View>

        <View
          style={{
            justifyContent: "center",
            marginTop: 10,
            alignItems: "center",
            backgroundColor: "#FAB707",
            borderRadius: 10,
            width: "100%",
            height: "30%",
          }}
        >
          <Text style={{ fontSize: 30, color: "#fff" }}>
            {receivedData.key}
          </Text>
          <Text style={{ fontSize: 30, color: "#fff" }}>AADHAR Verified</Text>
          {/* <Text style={{ fontSize: 30, color: "#fff" }}>Successfully</Text> */}
          <Text style={{ fontSize: 20, color: "#fff" , textAlign:'center'}}>{receivedData[0]}</Text>
         
        </View>
        {/* <View style={{ marginTop: 20 }}>
          <ActivityIndicator style={{ color: "red" }} size="large" />
        </View> */}
        <Text style={{ fontSize: 30,height:50, marginTop: 50, color: "#FAB707" }}>
          Aadhaar Details 
        </Text>
        {/* <Text style={{ fontSize: 16, color: "#FAB707" }}>
          please wait........
        </Text> */}
         
 

        <View
          style={{
            justifyContent: "center",
            marginTop: 10,
            alignItems: "center",
            backgroundColor: "#fff",
            borderRadius: 10,
            width: "100%",
            height: 280,
          }}
        >
          
          <Text style={{ fontSize: 20, color: "#FAB707" }}>Gender : {receivedData[4]}</Text>
          {/* <Text style={{ fontSize: 20, color: "#FAB707" }}>
            Date of Birth : {receivedData[3]}
          </Text> */}
          
          <TouchableOpacity
          onPress={createTwoButtonAlert} 
          style={styles.loginBtn}
        >
          <Text style={styles.loginText}>End Shift</Text>
        </TouchableOpacity>
        </View>
      </View>
      <TouchableOpacity
         
          style={styles.loginBtn}
        >
          <Text style={styles.loginText}>Logout</Text>
        </TouchableOpacity>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    backgroundColor: "#fff",
    alignItems: "center",
    padding: 10,
    // justifyContent: "center",
  },
  loginBtn: {
    width: "30%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: 'center',
    marginTop: 20,
    margin:10,
    backgroundColor: "#FAB707",
  },
  horizontal: {
    flexDirection: "row",
    // justifyContent: 'space-around',
    justifyContent: "center",
    padding: 10,
    flexDirection: "column",
    marginTop: 20,
    width: "100%",
    height: "30%",
  },
  loginText:{
    fontSize:16,
    
    
  }
});
