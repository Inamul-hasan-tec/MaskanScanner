// import { StyleSheet, Text, View } from 'react-native'
// import React from 'react'

// import React from "react";
// import Splash from "./screens/Splash";
// import { NavigationContainer } from "@react-navigation/native";
// // import { createStackNavigator } from "@react-navigation/stack";
// // import Home from './screens/Home'
// import Login from './Login';
// import CreateAccount from './CreateAccount';
// import Focus from './Focus';
// import ScanPage from './ScanPage';

// const AppNavigation = () => {
//   return (
   
//     <Stack.Navigator>
//     <Stack.Screen  component={Login} name="login" />
//     <Stack.Screen  component={CreateAccount} name="CreateAccount" />
//     <Stack.Screen  component={ScanPage} name="ScanPage" />
//     <Stack.Screen  component={Focus} name="Focus" />

//     </Stack.Navigator>
 
//   )
// }

// export default AppNavigation

// const styles = StyleSheet.create({})