import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Button } from "react-native";
import React, { useState, useEffect } from "react";
import { BarCodeScanner } from "expo-barcode-scanner";
import axios from "axios";
import { baseURL } from "./const/const";
import * as convert from "xml-js";
import { useNavigation } from "@react-navigation/native";

export default function Focus({ navigation }) {
  const [data, setData] = useState({
    uid: "",
    name: "",
    moble: "",
  });
  const [responseData , setResponseData] = useState();
  

  const fetchData = async () => {
    console.log("Entered the fetch data");
    try {
      // const response = await axiosInstance.post("/sec/auth/login",JSON.stringify(data),{"Accept" : "Application/json"});
      const response = await axios.post(
        `${baseURL}/verify-user`,
        JSON.stringify(data),
        {
          Accept: "Application/json",
        }
      );
      console.log("Post data : ", response);

      setResponseData(response);
      alert(response);
      // navigate("Addplan", { replace: true });
    } catch (error) {
      alert("Fill the details properly", error);
      console.log(error.response);
    }
  };
  console.log("Data = !!!!!!", JSON.stringify(data));

  

  useEffect(() => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === "granted");
    })();
  }, []);

  if (!hasPermission) {
    return (
      <View style={styles.container}>
        <Text>Please grant camera permissions to app.</Text>
      </View>
    );
  }

  const handleBarCodeScanned = ({ type, data }) => {
    let result = JSON.parse(convert.xml2json(data));
    // console.log("XML to JSON : ", typeof( result));
    console.log("parsed data : ", result?.elements[0]?.attributes?.uid);
    setAadhaaruid(result?.elements[0]?.attributes?.uid);

    
    
    navigate("Report");
    // navigation.navigate("Report");
    // console.log("XML to JSON 2 : ", result?.declaration);

    // let result2 = convert.xml2json(data, { compact: true, spaces: 4 });

    // console.log("XML to JSON  2 : ", result2);

    // let result3 = convert.xml2json(data, { compact: false, spaces: 4 });

    // console.log("XML to JSON 3: ", result3?.elements[0]?.attributes?.uid);
    // setAadhaaruid(result?.elements[0]?.attributes?.uid);
    // sadasd.elements[0].attributes.uid

    // console.log(Type: ${type});
  };

  return (
    <View style={styles.container}>
      <BarCodeScanner
        style={StyleSheet.absoluteFillObject}
        onBarCodeScanned={scanData ? undefined : handleBarCodeScanned}
      />
      {scanData && (
        <Button title="Scan Again?" onPress={() => setScanData(undefined)} />
      )}
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  containerF: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  btn: {
    // backgroundColor:'#FAB707'
  },
});

// const sadasd = {
//     declaration: { attributes: { version: "1.0", encoding: "UTF-8" } },
//     elements: [
//         {
//             type: "element",
//             name: "PrintLetterBarcodeData",
//             attributes: {
//                 uid: "606910505045",
//                 name: "Inamul Hasan",
//                 gender: "M",
//                 yob: "2001",
//                 co: "S/O: Mukthar Ahmed",
//                 house: "#16",
//                 street: "D No 1st Street",
//                 loc: "Shivaji Road Cross",
//                 vtc: "Bangalore North",
//                 po: "H.k.p. Road",
//                 dist: "Bangalore",
//                 subdist: "Bangalore North",
//                 state: "Karnataka",
//                 pc: "560051",
//                 dob: "05/04/2001",
//             },
//         },
//     ],
// };

// sadasd.elements[0].attributes.uid
