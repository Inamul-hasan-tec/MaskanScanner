import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
} from "react-native";
import { baseURL } from "./const/const";
export default function CreateAccount() {
  const [username, setusername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mobile, setMobile] = useState("");
  
  const handleRegister = () => {
    const apiUrl = `http://${baseURL}/register-user`;

    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');

    const raw = JSON.stringify({
      username: username,
      email: email,
      mobile: mobile,
      password: password,
    });

    const requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw,
      redirect: 'follow',
    };

    fetch(apiUrl, requestOptions)
      .then(response => response.text())
      .then(result => console.log(result))
      .catch(error => console.log('error', error));
  };
  return (
    <View style={styles.container}>
      <Image style={styles.image} source={require("../assets/adhar.png")} /> 
      <StatusBar style="auto" />
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
         
          placeholder="Username"
        value={username}
        onChangeText={text => setusername(text)}
        
        autoCapitalize="none"
        /> 
      </View> 
      <View style={styles.inputView}>
      <TextInput
          style={styles.TextInput}
         
          placeholder="email"
        value={email}
        onChangeText={text => setEmail(text)}
        
        autoCapitalize="none"
        /> 
        {/* <TextInput
          style={styles.TextInput}
          placeholder="Email."
          placeholderTextColor="#003f5c"
          onChangeText={(email) => setEmail(email)}
        />  */}
      </View> 
      <View style={styles.inputView}>
      <TextInput
          style={styles.TextInput}
         
          placeholder="mobile"
        value={mobile}
        onChangeText={text => setMobile(text)}
        
        autoCapitalize="none"
        /> 
      </View> 
      <View style={styles.inputView}>
      <TextInput
          style={styles.TextInput}
         
          placeholder="password"
        value={password}
        onChangeText={text => setPassword(text)}
        secureTextEntry={true}
        autoCapitalize="none"
        />
      </View> 
      {/* <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Confirm Password."
          placeholderTextColor="#003f5c"
          secureTextEntry={true}
          onChangeText={(password) => setPassword(password)}
        /> 
      </View>  */}
      {/* <TouchableOpacity>
        <Text style={styles.forgot_button}>Forgot Password?</Text> 
      </TouchableOpacity>  */}
      <TouchableOpacity onPress={handleRegister} style={styles.loginBtn}>
        <Text style={styles.loginText}>Create Account</Text> 
      </TouchableOpacity> 
    
    </View> 
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    marginBottom: 40,
    width:"50%",
    height:120
  },
  inputView: {
    backgroundColor: "#FAB707",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,
    alignItems: "center",
  },
  TextInput: {
    height: 50,
    flex: 1,
    
    padding: 10,
    marginLeft: 20,
  },
  forgot_button: {
    height: 30,
    marginBottom: 30,
  },
  loginBtn: {
    width: "80%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    backgroundColor: "#FAB707",
  },
});