// import { StatusBar } from "expo-status-bar";

// import React, { useState, useEffect } from "react";
// import { BarCodeScanner } from "expo-barcode-scanner";
// import axios from "axios";
// import { baseURL } from "./const/const";
// import * as convert from "xml-js";
// import { useNavigation } from "@react-navigation/native";


// import {
//   StyleSheet,
//   Text,
//   View,`````
//   Image,
//   TextInput,
//   Button,
//   TouchableOpacity,
// } from "react-native";
// import Focus from "./Focus";
// // import Focus from "./Focus";
// export default function ScanPage({ navigation }) {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [aadhaaruid, setAadhaaruid] = useState("");
//   const [hasPermission, setHasPermission] = React.useState(false);
//   const [scanData, setScanData] = React.useState();
//   const [data, setData] = useState({
//     uid: "",
//     name: "",
//     moble: "",
//   });
//   const [responseData ,setReponseData] = useState('no data');

//   const fetchData = async () => {
//     console.log("Entered the fetch data");
//     try {
//       // const response = await axiosInstance.post("/sec/auth/login",JSON.stringify(data),{"Accept" : "Application/json"});
//       const response = await axios.post(
//         `${baseURL}/verify-user`,
//         JSON.stringify(data),
//         {
//           Accept: "Application/json",
//         }
//       );
//       console.log("Post data : ", response);

//       setReponseData(response)

//       alert(response);
//       // navigate("Addplan", { replace: true });
//     } catch (error) {
//       alert("Fill the details properly", error);
//       console.log(error.response);
//     }
//   };
//   console.log("Data = !!!!!!", JSON.stringify(data));
//   useEffect(() => {
//     (async () => {
//       const { status } = await BarCodeScanner.requestPermissionsAsync();
//       setHasPermission(status === "granted");
//     })();

//     fetchData();


//   }, []);

//   if (!hasPermission) {
//     return (
//       <View style={styles.container}>
//         <Text>Please grant camera permissions to app.</Text>
//       </View>
//     );
//   }

//   const handleBarCodeScanned = ({ type, data }) => {
//     let result = JSON.parse(convert.xml2json(data));
//     // console.log("XML to JSON : ", typeof( result));
//     console.log("parsed data : ", result?.elements[0]?.attributes?.uid);
//     setAadhaaruid(result?.elements[0]?.attributes?.uid);
//     alert(responseData);
//     navigation.navigate("Report");
//   };
//   return (
//     <View style={styles.container}>
//       <Image style={styles.image} source={require("../assets/adhar.png")} />
//       <StatusBar style="auto" />
//       <View
//         style={{
//           width: "80%",
//           height: 350,
//           borderWidth: 1,
//           borderColor: "#FAB707",
//         }}
//       >
//         <View style={styles.containerF}>
//         <BarCodeScanner 
//         style={StyleSheet.absoluteFillObject}
//         onBarCodeScanned={scanData ? undefined : handleBarCodeScanned}
//         />
        
//       {/* {scanData && <Button  title='Scan Again?' onPress={() => setScanData(undefined)} />} */}
      
//       <StatusBar style="auto" />
//         </View>
//       </View>
//       {/* <View style={styles.inputView}>
//         <TextInput
//           style={styles.TextInput}
//           placeholder="Name"
//           placeholderTextColor="#003f5c"
//           onChangeText={(email) => setEmail(email)}
//         /> 
//       </View> 
//       <View style={styles.inputView}>
//         <TextInput
//           style={styles.TextInput}
//           placeholder="Email."
//           placeholderTextColor="#003f5c"
//           onChangeText={(email) => setEmail(email)}
//         /> 
//       </View> 
//       <View style={styles.inputView}>
//         <TextInput
//           style={styles.TextInput}
//           placeholder="Password."
//           placeholderTextColor="#003f5c"
//           onChangeText={(email) => setEmail(email)}
//         /> 
//       </View> 
//       <View style={styles.inputView}>
//         <TextInput
//           style={styles.TextInput}
//           placeholder="Confirm Password."
//           placeholderTextColor="#003f5c"
//           secureTextEntry={true}
//           onChangeText={(password) => setPassword(password)}
//         /> 
//       </View>  */}
//       {/* <TouchableOpacity>
//         <Text style={styles.forgot_button}>Forgot Password?</Text> 
//       </TouchableOpacity>  */}
//       {/* {scanData && <Button  title='Scan Again?' onPress={() => setScanData(undefined)} />} */}
     
//       <TouchableOpacity
//         onPress={() => setScanData(undefined)}
//         style={styles.loginBtn}
//       >
//         <Text style={styles.loginText}>Scan</Text>
//       </TouchableOpacity>
//     </View>
//   );
// }
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#fff",
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   containerF: {
//     flex: 1,
//     backgroundColor: "#fff",
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   image: {
//     marginBottom: 40,
//     width: "50%",
//     height: 120,
//   },
//   inputView: {
//     backgroundColor: "#FAB707",
//     borderRadius: 30,
//     width: "70%",
//     height: 45,
//     marginBottom: 20,
//     alignItems: "center",
//   },
//   TextInput: {
//     height: 50,
//     flex: 1,

//     padding: 10,
//     marginLeft: 20,
//   },
//   forgot_button: {
//     height: 30,
//     marginBottom: 30,
//   },
//   loginBtn: {
//     width: "80%",
//     borderRadius: 25,
//     height: 50,
//     alignItems: "center",
//     justifyContent: "center",
//     marginTop: 40,
//     backgroundColor: "#FAB707",
//   },
//   loginText: {
//     fontSize: 20,
//   },
// });


import axios from "axios";

const postUserData = async (userData) => {
  try {
    const response = await axios.post(
      "http://192.168.1.17:1000/verify-user",
      JSON.stringify(userData),
      {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      }
    );

    console.log("Post data response:", response.data);

    return response.data; // You can return the response if needed
  } catch (error) {
    console.error("Error posting data:", error);
    throw error; // You can throw the error or handle it as per your needs
  }
};

// Example of how to use the function with your 'aadhaaruid' state variable
const aadhaaruidGp = {
  "co": "S/O: Mukthar Ahmed",
  "dist": "Bangalore",
  "dob": "05/04/2001",
  "gender": "M",
  "house": "#16",
  "id": 25,
  "loc": "Shivaji Road Cross",
  "mobile": null,
  "name": "Inamul Hasan",
  "pc": "560051",
  "po": "H.k.p. Road",
  "state": "Karnataka",
  "street": "D No 1st Street",
  "subdist": "Bangalore North",
  "uid": "606910505045",
  "vtc": "Bangalore North",
  "yob": "2001",
};

// Call the function with your 'aadhaaruid' data
postUserData(aadhaaruidGp)
  .then((responseData) => {
    // Handle the response data if needed
    console.log("Response from API:", responseData);
  })
  .catch((error) => {
    // Handle errors if the POST request fails
    console.error("Error posting data:", error);
  });

