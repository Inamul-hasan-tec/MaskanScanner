export const baseURL = "http://192.168.43.175:1000";


// var Pdata = {
//     "uid": finalData?.uid,
//     "name": finalData?.name,
//     "mobile":finalData?.mobile,
//     "gender": finalData?.gender,
//     "yob": finalData?.yob,
//     "co": finalData?.co,
//     "house":finalData?.house,
//     "street": finalData?.street,
//     "loc": finalData?.loc,
//     "vtc": finalData?.vtc,
//     "po": finalData?.po,
//     "dist":finalData?.dist,
//     "subdist": finalData?.subdist,
//     "state":finalData?.state,
//     "pc":finalData?.pc,
//     "dob": finalData?.dob,
//     "email": finalData?.email,
//     "geo_loc": "Bangalore",
//   } 