import { SafeAreaView, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { SelectList } from 'react-native-dropdown-select-list'

export default function DepotScreen() {
    const [selected, setSelected] = React.useState("");
  
  const data = [
    { key: '1', value: 'ACHAMPET', disabled: false },
    { key: '2', value: 'ADILABAD', disabled: false },
    { key: '3', value: 'ARMOOR', disabled: false },
    { key: '4', value: 'ASIFABAD', disabled: false },
    { key: '5', value: 'BANDLAGUDA', disabled: false },
    { key: '6', value: 'BANSWADA', disabled: false },
    { key: '7', value: 'BHAINSA', disabled: false },
    { key: '8', value: 'BARKATPURA', disabled: false },
    { key: '9', value: 'BHEL', disabled: false },
    { key: '10', value: 'BHADRACHALAM', disabled: false },
    { key: '11', value: 'BHUPALAPALLE', disabled: false },
    { key: '12', value: 'BODHAN', disabled: false },
    { key: '13', value: 'CHENGICHERLA', disabled: false },
    { key: '14', value: 'CONTONMENT', disabled: false },
    { key: '15', value: 'DEVARAKONDA', disabled: false },
    { key: '16', value: 'DILSUKHNAGAR', disabled: true },
    { key: '17', value: 'DUBBAKA', disabled: false },
    { key: '18', value: 'FALAKNUMA', disabled: false },
    { key: '19', value: 'FAROOQNAGAR', disabled: false },
    { key: '20', value: 'GADWAL', disabled: false },
    { key: '21', value: 'GAJWEL-PRAGNAPUR', disabled: false },
    { key: '22', value: 'GODAVARIKHANI', disabled: false },
    { key: '23', value: 'HAKEEMPET', disabled: false },
    { key: '24', value: 'HANAMKONDA', disabled: false },
    { key: '25', value: 'HAYATNAGAR -1', disabled: false },
    { key: '26', value: 'HAYATNAGAR -2', disabled: false },
    { key: '27', value: 'HUSNABAD', disabled: false },
    { key: '28', value: 'HUZURABAD', disabled: false },
    { key: '29', value: 'HYDERABAD CENTRAL UNIVERSITY', disabled: false },
    { key: '30', value: 'HYDERABAD -1', disabled: false },
    { key: '31', value: 'HYDERABAD -2', disabled: false },
    { key: '32', value: 'IBRAHIMPATNAM-HYD', disabled: false },
    { key: '33', value: 'JAGITYAL', disabled: false },
    { key: '34', value: 'JANGAON', disabled: false },
    { key: '35', value: 'JEEDIMETLA', disabled: false },
    { key: '36', value: 'KACHIGUDA', disabled: false },
    { key: '37', value: 'KALWAKURTHY', disabled: false },
    { key: '38', value: 'KAMAREDDY', disabled: false },
    { key: '39', value: 'KARIMNAGAR -1', disabled: false },
    { key: '40', value: 'KARIMNAGAR -2', disabled: false },
    { key: '41', value: 'KHAMMAM', disabled: false },
    { key: '42', value: 'KODAD', disabled: false },
    { key: '43', value: 'KOLLAPUR', disabled: false },
    { key: '44', value: 'KORUTLA', disabled: false },
    { key: '45', value: 'KOTHAGUDEM', disabled: false },
    { key: '46', value: 'KOSGI', disabled: false },
    { key: '47', value: 'KUKATPALLY', disabled: false },
    { key: '48', value: 'KUSHAIGUDA', disabled: false },
    { key: '49', value: 'MADHIRA', disabled: false },
    { key: '50', value: 'MAHABOOBABAD', disabled: false },
    { key: '51', value: 'MAHABOOBNAGAR', disabled: false },
    { key: '52', value: 'MAHESWARAM', disabled: false },
    { key: '53', value: 'MANCHERIAL', disabled: false },
    { key: '54', value: 'MANTHANI', disabled: false },
    { key: '55', value: 'MANUGUR', disabled: false },
    { key: '56', value: 'MEDAK', disabled: false },
    { key: '57', value: 'MEDCHAL', disabled: false },
    { key: '58', value: 'MEHADIPATNAM', disabled: false },
    { key: '59', value: 'METPALLY', disabled: false },
    { key: '60', value: 'MIDHANI', disabled: false },
    { key: '61', value: 'MIRYALGUDA', disabled: false },
    { key: '62', value: 'MIYAPUR -1', disabled: false },
    { key: '63', value: 'MIYAPUR -2', disabled: false },
    { key: '64', value: 'MUSHIRABAD -1', disabled: false },
    { key: '65', value: 'MUSHIRABAD -2', disabled: false },
    { key: '66', value: 'NAGARKURNOOL', disabled: false },
    { key: '67', value: 'NALGONDA', disabled: false },
    { key: '68', value: 'NARAYANAKHED', disabled: false },
    { key: '69', value: 'NARAYANPET', disabled: false },
    { key: '70', value: 'NARKETPALLY', disabled: false },
    { key: '71', value: 'NARSAMPET', disabled: false },
    { key: '72', value: 'NARSAPUR', disabled: false },
    { key: '73', value: 'NIRMAL', disabled: false },
    { key: '74', value: 'NIZAMABAD -1', disabled: false },
    { key: '75', value: 'NIZAMABAD -2', disabled: false },
    { key: '76', value: 'PARGI', disabled: false },
    { key: '77', value: 'PARKAL', disabled: false },
    { key: '78', value: 'PICKET', disabled: false },
    { key: '79', value: 'RAJENDRANAGAR', disabled: false },
    { key: '80', value: 'RANIGUNJ -1', disabled: false },
    { key: '81', value: 'RANIGUNJ -2', disabled: false },
    { key: '82', value: 'SANGA REDDY', disabled: false },
    { key: '83', value: 'SATTUPALLY', disabled: false },
    { key: '84', value: 'SHADNAGAR', disabled: false },
    { key: '85', value: 'SIDDIPET', disabled: false },
    { key: '86', value: 'SIRCILLA', disabled: false },
    { key: '87', value: 'SURYAPET', disabled: false },
    { key: '88', value: 'TANDUR', disabled: false },
    { key: '89', value: 'TORRUR', disabled: false },
    { key: '90', value: 'UPPAL', disabled: false },
    { key: '91', value: 'UTNOOR', disabled: false },
    { key: '92', value: 'VEMULAWADA', disabled: false },
    { key: '93', value: 'VIKARABAD', disabled: false },
    { key: '94', value: 'WANAPARTHY', disabled: false },
    { key: '95', value: 'WARANGAL -1', disabled: false },
    { key: '96', value: 'WARANGAL -2', disabled: false },
    { key: '97', value: 'YADAGIRIGUTTA', disabled: false },
    { key: '98', value: 'ZAHIRABAD', disabled: true },
  ];
  
  return (
   
    <View style={styles.container}>
      
     <View style={{marginHorizontal:10}}  >
     <SelectList 
        setSelected={(val) => setSelected(val)} 
        data={data} 
        save="value"/>
        
     </View>
     <View style={{marginHorizontal:10}} >
     <SelectList 
        setSelected={(val) => setSelected(val)} 
        data={data} 
        save="value"/>
        
     </View>
      


    </View>
   
  )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        alignItems: "center",
        justifyContent: "center",
      },
   
})