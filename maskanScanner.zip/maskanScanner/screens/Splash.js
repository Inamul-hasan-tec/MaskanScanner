import {  Text,StyleSheet, TouchableOpacity } from 'react-native'
import { View, Animated } from 'react-native';
import React, { useState } from 'react'

// import Login from './Login';
// import { StateNavigator } from 'navigation';
// import Login from './Login'


const Splash = ({navigation}) => {
  const imageScale = new Animated.Value(0.4);

  Animated.timing(imageScale, {
    toValue: 1,
    duration: 2100,
    useNativeDriver: true,
  }).start();

  useState(()=>{
       setTimeout(() => {
        
        navigation.navigate('Login')
       }, 3500);
  },[])
  return (
    
    <View style={styles.container}>

      
    <View style={{width:'100%',  justifyContent:'center', alignItems:'center', marginTop:100}}>

    <Animated.Image
        source={require('../assets/ladiesBus.jpg')}
        style={[styles.image, { transform: [{ scale: imageScale }] }]}
      />

      <View style={{marginTop:40, gap:5,alignItems:'center',justifyContent:'center'}}>
        <Text style={{fontSize:30,color:'#D52736'}}>Welcome to</Text>
        <Text style={{fontSize:27, width:"90%",  color:'#FAB707'}}>Narishakti</Text>
        <Text style={{fontSize:30,  color:'#D52736'}}> App </Text>
      </View>
      <View style={{marginTop:60,flexDirection:'row',gap:60}}>
      {/* <TouchableOpacity  onPress={() => navigation.navigate("Login")}>
        <Text style={styles.forgot_button}>Log In</Text> 
      </TouchableOpacity> 
      <TouchableOpacity  onPress={() => navigation.navigate("CreateAccount")}>
        <Text style={styles.forgot_button}>Create Account</Text> 
      </TouchableOpacity>  */}
      </View>
    </View>

     {/* <Login/> */}

      


    </View>
  )
}

export default Splash


const styles=StyleSheet.create({
    container:{
        padding:10,
        flex:1,
        justifyContainer:"center",
        alignItems:"center",
        backgroundColor:"#ffffff"
        
    },
    image: {
      width: 260,
      height: 260,
      borderRadius:120
    },
    forgot_button: {
      height: 30,
      marginBottom: 30,
      backgroundColor:'#FAB707',
      color:'black',
      borderRadius:5,

      padding:10
    },
    TextInput: {
      height: 50,
      flex: 1,
      
      padding: 10,
      marginLeft: 20,
    },
    // imglogo:{
         
    //     width: 216,
    //     height: 41,
        
    //     marginTop:200
        
    // },

})